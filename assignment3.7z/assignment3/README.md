## Flask API for Retail Dashboard With JS

- Download the zip folder from this directory
- Extract all the files and folders
- run python code/app.py in terminal
- Go to http://127.0.0.1:5000/
- Open login.html like live server
